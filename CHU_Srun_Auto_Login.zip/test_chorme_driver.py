'''
Author:Zzzzhouzh
Time:2025/3/9
Function:CHU's campus network automatic login
PS:截至该日期，该脚本仍然适用CHU的校园网认证计费技术厂商-深澜Srun

本工程文件配置好库后，更改4个参数，即可运行使用。
49行：更改你的ChromeDriver所在的绝对路径
53行：更改成你学校的Srun校园网登录网址
93行：更改成你的账号
98行：更改成你的密码
'''


from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException
import time  # 新增 time 模块


def check_login_status(driver):
    """检测是否已登录：通过注销按钮存在性判断"""
    try:
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "logout"))
        )
        return True
    except TimeoutException:
        return False


def srun_login():
    driver = None
    max_retries = 3  # 最大重试次数
    retry_delay = 5  # 重试间隔（秒）

    for attempt in range(max_retries):
        try:
            options = webdriver.ChromeOptions()
            options.add_argument('--headless')      # 启用无头模式,即运行脚本时候不显示浏览器页面
            options.add_argument('--disable-gpu')   # 禁用 GPU 加速（兼容性优化）
            options.add_argument('--no-sandbox')    # 禁用沙箱（Linux 环境推荐）
            options.add_argument('--disable-dev-shm-usage')     # 防止内存不足崩溃
            options.add_argument('--ignore-certificate-errors')
            service = Service(
                executable_path=r'C:\Program Files\Google\Chrome\Application\chromedriver-win64\chromedriver.exe')
            driver = webdriver.Chrome(service=service, options=options)

            # 尝试访问认证页面
            driver.get("https://beiradius.chd.edu.cn/srun_portal_pc?ac_id=5&theme=pro")
            break  # 访问成功则跳出循环

        except WebDriverException as e:
            error_msg = str(e)
            # 捕获特定网络错误
            if "ERR_NAME_NOT_RESOLVED" in error_msg or "ERR_CONNECTION_TIMED_OUT" in error_msg:
                print(f"第 {attempt + 1} 次连接失败，{retry_delay} 秒后重试...")
                if driver:
                    driver.quit()
                if attempt == max_retries - 1:
                    print("错误：无法连接到认证页面，请检查设备是否连接了校园网")
                    return False
                time.sleep(retry_delay)
            else:
                # 其他浏览器错误直接抛出
                if driver:
                    driver.quit()
                print(f"浏览器错误: {error_msg}")
                return False
        except Exception as e:
            if driver:
                driver.quit()
            print(f"意外错误: {str(e)}")
            return False

    # 如果所有重试均失败，直接返回
    if not driver:
        return False

    try:
        # 检测是否已登录
        if check_login_status(driver):
            print("当前已登录，无需重复认证")
            return True

        # 输入用户名密码
        username = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.ID, "username"))
        )
        username.send_keys("将这里删除后，更改成你的账号(引号别删)")

        password = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.ID, "password"))
        )
        password.send_keys("将这里删除后，更改成你的密码(引号别删)")

        # 点击登录按钮
        login_button = WebDriverWait(driver, 20).until(
            EC.element_to_be_clickable((By.ID, "login-account"))
        )
        login_button.click()

        # 验证登录成功
        WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.ID, "logout"))
        )
        print("认证成功！")
        return True

    except TimeoutException:
        print("错误：操作超时，请检查网络或页面元素是否变更")
        return False
    except Exception as e:
        print(f"运行时错误: {str(e)}")
        return False
    finally:
        if driver:
            driver.quit()


if __name__ == "__main__":
    result = srun_login()
    print("最终结果:", "成功" if result else "失败")